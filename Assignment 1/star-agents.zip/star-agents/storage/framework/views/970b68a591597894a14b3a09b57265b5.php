<?php $__env->startSection('title'); ?>
    Agency Details - WAD Assignment 1 (Matthew Prendergast: s5283740)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-header montserrat-heading">
            <h2>Agency Details</h2>
        </div>

        <!-- Display agency details -->
        <div class="clearfix agency-content">
            <div>
                <div class="mb-3">
                    <h4>Agency:</h4>
                    <p><?php echo e($agency->agency_name); ?></p>
                </div>

                <div class="mb-3">
                    <h4>Address:</h4>
                    <p><?php echo e($agency->agency_address); ?></p>
                </div>
            </div>
        </div>

        <!-- List of agents associated with this agency -->
        <div class="agent-list mt-4">
            <h4>Agents List</h4>

            <!-- Check if there are any agents for the agency -->
            <?php if(!empty($agents)): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Surname</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Review Count</th>
                            <th>Average Rating</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Loop through the agents and display their details -->
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr onclick="window.location='<?php echo e(route('view-agent', ['agentNumber' => $agent->id])); ?>'" style="cursor:pointer;">
                                <td><?php echo e($agent->first_name); ?></td>
                                <td><?php echo e($agent->surname); ?></td>
                                <td><?php echo e($agent->email); ?></td>
                                <td><?php echo e($agent->phone); ?></td>
                                <!-- Handle case where no reviews are recorded for the agent -->
                                <?php if(is_null($agent->average_rating)): ?>
                                    <td colspan="2">NO REVIEWS RECORDED</td>
                                <?php else: ?>
                                    <td><?php echo e($agent->review_count); ?></td>
                                    <td><?php echo e(number_format($agent->average_rating, 1)); ?></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <!-- Display message if no agents are found for the agency -->
                <p>No agents found for this agency.</p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/star-agents/resources/views/view-agency.blade.php ENDPATH**/ ?>