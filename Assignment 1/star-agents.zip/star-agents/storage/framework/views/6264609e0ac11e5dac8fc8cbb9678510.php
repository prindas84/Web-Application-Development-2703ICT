<?php $__env->startSection('title'); ?>
    Add Agent - WAD Assignment 1 (Matthew Prendergast: s5283740)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container page-content">
        <div class="page-header montserrat-heading">
            <h2>Add Agent</h2>
        </div>

        <!-- Display success message if present -->
        <?php if(session('success')): ?>
            <div class="alert alert-success mt-3">
                <?php echo session('success'); ?>

            </div>
            <script>
                // Reload the page after 2 seconds
                setTimeout(function() {
                    location.reload();
                }, 2000);
            </script>
        <?php endif; ?>

        <!-- Display error message if present -->
        <?php if(session('error')): ?>
            <div class="alert alert-danger mt-3" id="error-alert">
                <?php echo session('error'); ?>

            </div>
            <script>
                // Hide error message after 3 seconds
                setTimeout(function() {
                  document.getElementById('error-alert').style.display = 'none';
                }, 3000);
            </script>
        <?php endif; ?>

        <!-- Form to add a new agent -->
        <form id="add-agent-form" action="<?php echo e(route('add-agent')); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- CSRF token for security -->

            <div class="form-group">
                <label for="first_name">First Name*</label>
                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e(old('first_name')); ?>">
            </div>

            <div class="form-group">
                <label for="surname">Surname*</label>
                <input type="text" class="form-control" id="surname" name="surname" value="<?php echo e(old('surname')); ?>">
            </div>

            <div class="form-group">
                <label for="position">Position*</label>
                <input type="text" class="form-control" id="position" name="position" value="<?php echo e(old('position')); ?>">
            </div>

            <div class="form-group">
                <label for="biography">Biography*</label>
                <textarea class="form-control" id="biography" name="biography"><?php echo e(old('biography')); ?></textarea>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number*</label>
                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone')); ?>">
            </div>

            <div class="form-group">
                <label for="email">Email Address*</label>
                <input type="text" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">
            </div>

            <!-- Dropdown to select an agency for the agent -->
            <div class="form-group">
                <label for="agency_id">Select Agency*</label>
                <select class="form-control" id="agency_id" name="agency_id">
                    <option value="">[ Select Agency ]</option>
                    <?php $__currentLoopData = $agencyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($agency->id); ?>" <?php echo e(old('agency_id') == $agency->id ? 'selected' : ''); ?>>
                          <?php echo e($agency->agency_name); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary mt-3">Add Agent</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/star-agents/resources/views/add-agent.blade.php ENDPATH**/ ?>