<?php $__env->startSection('title'); ?>
    Add Agency - WAD Assignment 1 (Matthew Prendergast: s5283740)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container page-content">
        <div class="page-header montserrat-heading">
            <h2>Add Agency</h2>
        </div>

        <!-- Display success message if present -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo session('success'); ?>

            </div>
            <script>
                // Reload the page after 2 seconds
                setTimeout(function() {
                    location.reload();
                }, 2000);
            </script>
        <?php endif; ?>

        <!-- Display error message if present -->
        <?php if(session('error')): ?>
            <div class="alert alert-danger" id="error-alert">
                <?php echo session('error'); ?>

            </div>
            <script>
                // Hide error message after 3 seconds
                setTimeout(function() {
                    document.getElementById('error-alert').style.display = 'none';
                }, 3000);
            </script>
        <?php endif; ?>

        <!-- Form to add a new agency -->
        <form id="add-agency-form" action="<?php echo e(route('add-agency')); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- CSRF token for security -->

            <div class="form-group">
                <label for="agency_name">Agency Name*</label>
                <input type="text" class="form-control" id="agency_name" name="agency_name" value="<?php echo e(old('agency_name')); ?>">
            </div>

            <div class="form-group">
                <label for="agency_address">Agency Address*</label>
                <input type="text" class="form-control" id="agency_address" name="agency_address" value="<?php echo e(old('agency_address')); ?>">
            </div>

            <button type="submit" class="btn btn-primary mt-3">Add Agency</button>
        </form>

        <!-- List of all Agencies -->
        <div class="mt-5">
            <h3>All Agencies</h3>
            <?php if(!empty($data)): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Agency Name</th>
                            <th>Agency Address</th>
                            <th>Average Rating</th>
                            <th>Delete Record</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Display each agency's details -->
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr onclick="window.location='<?php echo e(route('view-agency', $agency->agency_id)); ?>'" style="cursor:pointer;">
                                <td><?php echo e($agency->agency_name); ?></td>
                                <td><?php echo e($agency->agency_address); ?></td>
                                <!-- Display message if no reviews are recorded -->
                                <?php if(is_null($agency->average_rating)): ?>
                                    <td>NO REVIEWS RECORDED</td>
                                <?php else: ?>
                                    <td><?php echo e(number_format($agency->average_rating, 1)); ?></td>
                                <?php endif; ?>
                                <td>
                                    <form action="<?php echo e(route('delete-agency', $agency->agency_id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-link p-0 delete-agency" onclick="return confirm('Are you sure you want to delete this agency record?')">
                                            <img src="<?php echo e(asset('images/delete.png')); ?>" alt="Delete">
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No agencies found.</p> <!-- Message if no agencies are in the database -->
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/star-agents/resources/views/add-agency.blade.php ENDPATH**/ ?>